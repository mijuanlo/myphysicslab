                gladTeX 0.3+ for Windows
                ------------------------

This version of gladTeX is based on gladtex 0.3 from
http://www.math.uio.no/~martingu/gladtex/
Copyright (C) 1999-2002 Martin G. Gulbrandsen <martingu@math.uio.no>

Please see the accompanying 'readme' file for gladtex 0.3 which
spells out the GNU General Public License terms.

This version is by Erik Neumann  <erikn@myphysicslab.com> first released
September 2004.  I am making this version available to whoever might want it,
under the same GPL license terms.  For more info see
http://www.myphysicslab.com/gladtex/

This version of gladTeX is different in the following ways:
* Now works under Windows XP.
However, this version probably ONLY works under Windows until I or someone
attempts to make this version work both under Unix and Windows (not a difficult
job, but I don't have a Unix system to test it with).

* Avoids re-creating equation images that already exist.
Briefly, here's how it works:  the LaTeX equation is written to a *.tex file in
the same directory where the *.png file is created.  When gladTeX is asked to
render a certain LaTeX expression, it first scans all the available *.tex files
to see if that expression has already been rendered.  If so, it just uses the
existing *.png file with the same name.

* Improved how inline equation images are aligned with text.
GladTeX originally used the vertical centering of images to effect alignment
with the text -- gladTex would resize the image to add blank space above or
below so it would align.  This version instead uses a CSS "vertical-align" style
attribute in the <IMG> tag like this:
    <IMG style="vertical-align: -13px; margin: 0;" width="20" height="30">
With this attribute, we no longer need to make the image larger with blank
space.  This keeps the spacing between lines of text more compact.

* Names equation images to correspond to the HTML document they are from.
This helps me to keep track of what equation goes with what HTML document.  Note
that currently the 'avoid re-creating an image' code might find existing files
that 'belong' to a different page.  (It would be fairly simple to add an option
to prevent that behavior).

* Only supports PNG, not GIF (at present).
I decided that PNG was good enough, and didn't try to get the GIF code to work.

* Double-quotes not allowed in LaTeX expressions.
This is because of how I am using grep to search for existing files.  Since
Windows command-line arguments are wrapped in double-quotes, we pass the LaTeX
expression wrapped in double-quotes.  So, a double-quote in the LaTeX expression
would break that part of the process.  This is not a big problem since double-
quotes are pretty much not used in LaTeX anyway!  (LaTeX requires use of two
single quotes like '' or back quotes `` instead).  If you really need a double
quote you can use \\symbol{34} instead.  (Note that this limitation could be
eliminated by writing the search argument to a file instead of passing it via
the command-line).

Installation
------------
Get the two files (that are part of this software release):
    eqn2img.exe  (compiled for Windows OS)
    gladtex.pl
and put them somewhere that can be found by the Windows command line.
In addition you need the following.
perl
LaTeX (I recommend MikTeX)  for the commands latex and dvips
grep  (from http://www.interlog.com/~tcharron/grep.html)
ghostscript  for the command gswin32c.  see http://www.cs.wisc.edu/~ghost/.

Note that libpng is part of eqn2img.exe, so you don't need to install libpng on
your own.

Before trying to use gladtex, you should be able to run latex on a simple .tex
file, and turn it into a .dvi file (and view it with a .dvi viewer like Yap
which is part of MikTeX).

Usage
-----
Put
    <eq>...latex code here....</eq>
in your .html file.  But rename it to have the .htex extension.  Then invoke
gladtex by:
    perl gladtex.pl [options] myfile.htex
where [options] are described in gladtex.pl.

For inline equations use
    <eq inline=1>...latex code here...</eq>
This will result in special processing so that the equation image lines up with
the other text on the line.

Source Code
-----------
The perl file gladtex.pl is a simple perl text file.
The source code for eqn2img.c is provided in case you want to try to build it
yourself.  There are some additional .h and .c files:
    png.h is the header for libpng.
    getopt.c is code from the MSDN 2000 disk.
    direct.h header is for directory operations like _chdir

You will need to obtain libpng and zlib if you want to compile eqn2img.c.  This
is rather involved when using VisualC++ on Windows, see the accompanying file
'libpng notes.txt' for more information.

eqn2img changes
---------------
* Various changes so that it compiles and works on Windows.
* Added the -i option to specify when an equation is inline with the text.
Those equations are handled specially.  They result in the <img> tag have a
style="vertical-align" property so that they line up with the other text on that
line.  (In the old version of eqn2img this was done by increasing the size of
the image, so that align=middle property would line it up, but that resulted in
large spaces between lines of text).
* Added the -e option to specify the equation on the command line.
* No longer delete the .tex file.  It is used by gladtex to see if a .png image
can be reused.

