#!/usr/bin/perl -w

#    gladtex: Reads a 'htex' file (html with LaTeX maths embedded in <EQ></EQ>)
#             and produces html with equations substituted by images.
#    Project homepage at http://www.math.uio.no/~martingu/gladtex/
#    Copyright (C) 1999-2002 Martin G. Gulbrandsen <martingu@math.uio.no>
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

# note: the utility 'eqn2img' should accompany this script,
#       and must be callable from this script.

use IPC::Open2;
use Cwd;
use Getopt::Std;
#require 'getopts.pl'; -- replaced by GetOpt::Std module
#require 'getcwd.pl'; -- replaced by Cwd module

$img_dir = "."; # default values
$dpi = 100;
$supersample = 4;
$format = "png";
$verbose = 0;
$foreground = "000000";
$background = "A0A0A0";
$transparency = 1;

# WINDOWS NOTE:  preamble must be a single line on windows.
$preamble = "\\usepackage{amsmath} \\usepackage{amssymb}";

$usage = 
"gladtex version 0.3, Copyright (C) 1999-2002 Martin G. Gulbrandsen

gladtex comes with ABSOLUTELY NO WARRANTY. This is free software,
and you are welcome to redistribute it under certain conditions;
see the file COPYING for details.

Project homepage at http://www.math.uio.no/~martingu/gladtex/
Author email: <martingu\@math.uio.no>

Usage: gladtex [OPTION]... [FILE]...
Convert htex file (HTML with LaTeX equations) to html with images
  -v          print verbose information
  -f format   store images in 'format' (png by default)
  -r dpi      set resolution (size of images) to 'dpi' ($dpi by default)
  -s n        set oversampling factor for antialiasing to 'n' ($supersample by default)
  -d path     store image files in 'path' (current directory is default)
  -u url      url to image files above (relative links are default)
  -p string   add 'string' to LaTeX preamble (e.g. \\usepackage{...})
  -c colour   set foreground RGB colour ($foreground by default)
  -b colour   set background RGB colour ($background by default)
  -t          turn transparency OFF
  -e          run optional macro preprocessor at start

Output files:
  <file>.html    copy of input FILE(s), with <EQ>..</EQ> tags replaced
                 by <IMG> tags.
                 <file> is same as input file, with the extension replaced.
  <file>???.png  equation images.  filename is same as base file name with
                 numeric addition starting at 000, then 001, etc.
  <file>???.tex  LaTeX version of the equation, to enable later reuse of image
                 files.

Input files should not have .html extension, .htex is recommended.

Do not use double-quote symbol \" in equations, use \\symbol{34} instead.
";

$| = 1; # flush output after every print, causes better feedback with -v flag
$img_name = "eqn000";

# find directory separator symbol for the current OS.
if ($^O eq "MSWin32") {
  $dirsep = "\\";
} else {
  $dirsep = "/";
}

# --- sub: rel_name ---
# usage: rel_name $src, $dest;
# $src and $dest should be absolute paths
# returns: relative path to $dest, as seen from $src
sub rel_name {
  my @src = split /\//, shift;
  my @dest = split /\//, shift;
  my $path;
  my $i = 0;

  # let $i = first level where $src and $dest doesn't match
  for($i=0; $i <= $#src and $i <= $#dest and $src[$i] eq $dest[$i]; $i++) {};

  $path = "../" x ($#src - $i + 1);

  for(; defined $dest[$i]; $i++) {
    $path .= "$dest[$i]/";
  }

  return $path;
}

# --- sub: full_name ---
# usage: full_name $src, $dest
# $src should be some absolute path
# $dest may be relative (as seen from $src) or absolute
# returns absolute path to $dest, as seen from $src (without trailing /)
sub full_name {
  my $src = shift;
  my $dest = shift;

  # add trailing / if not present
  $dest .= "/" unless $dest =~ /\/$/;
  # if not absolute path, add $src
  $dest = $src . "/$dest"  unless $dest =~ /^\//;

  # remove ./
  $dest =~ s/\.\///g;
  # remove //
  while($dest =~ s{//}{/}gc) {};
  # remove ../
  while($dest =~ s{/([^/]*/)\.\./}{$1}gc) {};
  # remove trailing /
  $dest =~ s/\/$//;

  return $dest;
}

# --- Parse command line options ---

getopts('f:r:s:d:u:vtec:b:p:');

if($#ARGV < 0) {
  print $usage;
  print `eqn2img -f?`; # this prints list of supported formats
  exit;
}

$img_dir = $opt_d if defined $opt_d;
$dpi = $opt_r if defined $opt_r;
$supersample = $opt_s if defined $opt_s;
$format = $opt_f if defined $opt_f;
$verbose = $opt_v if defined $opt_v;
$erik_prep = $opt_e if defined $opt_e;
$transparency = 0 if defined $opt_t;
$preamble .= "$opt_p\n" if defined $opt_p;
$foreground = $opt_c if defined $opt_c;
$background = $opt_b if defined $opt_b;
if(defined $opt_u) {
  $url = $opt_u;
  $url .= "/" unless $url =~ /\/$/;
  if(!defined $opt_d) {
    print "\nWarning: -u option present, but no -d or -D\n\n";
  }
}
$opt_t = 0; # just do something with $opt_t to avoid 'possible typo' warning

# todo: add validization of options

if($opt_d and !defined $url) {
  $img_dir = full_name(getcwd(), $img_dir);
}

# --- Process input files ---

print "Processing ", $#ARGV + 1, " files\n" if $verbose;

$startup_cwd = getcwd();

foreach $file (@ARGV) {
  ($directory, $basename, $extension) = $file =~ /(.*?)\/*([^\/]*?)\.([^\/]*)$/;
  $directory or $directory = ".";
  $basename or $basename = "noname";
  $img_name = $basename;
  $img_num = "000";
  $extension or $extension = "htex";
  $extension eq "html" and die "Don't use .html extension, .htex is recommended.";

  if ($erik_prep) {
    # preprocess the file using Erik's macro 'prep' program.
    # (eventually get rid of this here when Erik figures out how to pipe files on Windows)
    open PREPTASK, "prep $file |"
      or die "can't fork prep task: $!";
    while ($prep_result = <PREPTASK>) {
      print $prep_result;
    }
    close PREPTASK;
    if ($?) {
      die "prep had a problem ($?) ... quitting.\n";
    }
    $extension = "prep";
  }
  
  $full_dir = full_name($startup_cwd, $directory);
  if(getcwd() ne $full_dir) {
    chdir $full_dir;
    if(!$opt_d) {
      %history = ();
      $img_name = "eqn";
    }
  }

  open(INPUT, "$basename.$extension") or die "Cannot open $basename.$extension";
  open(OUTPUT, ">$basename.html") or die "Cannot open $basename.html";
  
  print "\n$basename.$extension -> $basename.html\n" if $verbose;
  print "Putting images in directory $img_dir\n" if ($opt_d && $verbose);
  
  for($start_line = 1; not eof INPUT; $start_line++) {
    $line = <INPUT>;

    # search for <eq> tag (the s option is needed to avoid losing linebreak at end of line)
    while($line =~ /(.*?)<eq(.*?)>(.*)/is) {
      print OUTPUT $1; # everything before <eq> tag
      $options = $2;   # anything between '<eq' and '>'
      $line = $3;      # the rest

      $this_preamble = $preamble;
      $this_foreground = $foreground;
      $this_background = $background;
      $this_inline = 0;
      
      # scan options within <eq> tag
#     while($options =~ /\s*?(\S*?)=(\S*)/g) { # should whitespace be allowed around equal sign?
      # should whitespace be allowed around equal sign?
      while($options =~ /\s*?(\S*?)=\s*(\"(.*?)\"|\'(.*?)\'|(\S*))/g) { 
        $key = $1;

        # only one of these will be defined
        $value = $3 if defined $3; # "value"
        $value = $4 if defined $4; # 'value'
        $value = $5 if defined $5; # value (no quotation marks)
        # is there a better way to scan for key/value pairs?

        foreach($key) { # may add more options here when needed..
          /^preamble/i and $this_preamble .= "$value\n";
          /^color/i and $this_foreground = $value;
          /^bgcolor/i and $this_background = $value;
          /^inline/i and $this_inline = 1;
        }
      }

      $equation = "";
      $end_line = $start_line;

      # read equation until </eq> is found
      while(not (($before, $after) = ($line =~ /(.*?)<\/eq>(.*)/is)) ) {
        $equation .= "$line\n";
        if(eof INPUT) {
          print "Closing tag </eq> not found in equation started at line $start_line\n";
          # todo: cleanup
          exit;
        }
        $line = <INPUT>;
        $end_line++;
      }
      $equation .= $before; # everything before </eq>
      $line = $after;       # everything after </eq>

      # strip whitespace: this makes 'history' stronger and removes linebreak
      # trouble (a paragraph can't end within $$..$$ in latex)
      $equation =~ s/\s+/ /g;

      print "Processing ".($this_inline ? "inline " : ""). "equation at line(s) $start_line to $end_line:\n" if $verbose;
      print "Equation is $equation\n" if $verbose;
      
      # see comments before grep for more info on double quote problem.
      if ($equation =~ m/\"/) {
        print "WARNING: double-quotes in equation prevents re-use of equation images.\n";
      }
      
      if($opt_u) {
        $img_src = $url;
      } else {
        if($opt_d) {
          $img_src = rel_name(getcwd(), $img_dir);
        } else {
          $img_src = "";
        }
      }
      
      # WINDOWS NOTE:  use double quotes around the preamble (single quotes in unix).
      # The -i option for eqn2img specifies that the image is inline with the text, 
      # so it should be vertically centered.
      $eqn2img_opt = "-r $dpi -p \"$this_preamble\" -c $this_foreground -b $this_background -f $format -s $supersample " 
        . ($transparency ? "" : "-t ") . ($verbose ? "-v " : "") . ($this_inline ? "-i " : "");
      $eqn2img_opt2 = $eqn2img_opt;
      $eqn2img_opt2 =~ s/\"//g;  #strip out quotes, see comments below about grep.
      
      # --- process the latex code in $equation ---
      # recycle image if the same equation has appeared before with the
      # same options (colors etc.)
      if(defined $history{$equation} and $history{$equation}->{"opt"} eq $eqn2img_opt) {
        print "Reusing image\n" if $verbose;
      } else {
        # --- Search for an existing .png file, by looking at associated .tex files. ---
        # Only works for .png files, not for .gif files.
        $preexist = 0;
        # Here we search for both the equation and the options.
        # Options are written in a TeX comment (% symbol), all on a single line.
        # We stripped out the quotes from the options so that it can be supplied to grep
        # as a quoted string on the command line in Windows.
        
        # This limits us to using equations without double-quotes.
        # The " symbol will almost never occur in a LaTeX equation.  The George Gratzer
        # book Math Into Latex states on p. 82 that 'the " key should never be used
        # in text;  see Section 2.4.1 for the proper way to typeset double quotes.'
        # If you really need a ", then use \symbol{34} in the equation.
        # Alternatively we could write the pattern to search for into a file, and 
        # use grep -f "file".
        
        # Windows note:  Using \ for directory separator in grep input (fix for unix).
        open GREPTASK, ("grep -F \"\$\$" . ($this_inline ? "\." : "") .
            "$equation\%$eqn2img_opt2\" $img_dir$dirsep*.tex |")
              or die "can't fork grep task: $!";
        $grep_result = <GREPTASK>;
        close GREPTASK;
        if ($grep_result) {
          #find the file name by searching for everything up to the first "."
          @words = split /\./, $grep_result;
          chomp($words[0]);  # why does perl put a newline at end of every variable???
          $pngfile = $words[0] . ".png";
#          $texfile = $words[0] . ".tex";
          open TEXFILE, "<$img_dir/$words[0].tex";
          while (<TEXFILE>) {
            if (/^\%img_attributes(.+)/) {
              # the regular expression sets $1 to be the remainder of the line
              print "Found pre-existing $pngfile\n" if $verbose;
              $history{$equation}->{"opt"} = $eqn2img_opt;
              $history{$equation}->{"img"} = $pngfile;
              $history{$equation}->{"dim"} = $1;  
              $preexist = 1;
            }
          }
          close TEXFILE;
          # we use a C program called 'pngsize' that returns the dimensions of the png file.
          # (note: could use the perl add-in called GD instead of this C program).
#          open DIMTASK, "pngsize $img_dir$dirsep$pngfile |"
#            or die "can't fork pngsize task: $!";
#          $dimstring = <DIMTASK>;
#          close DIMTASK;
#          if (defined $dimstring && $dimstring =~ /^WIDTH=/) {
#            print "Found pre-existing $pngfile\n" if $verbose;
#            $history{$equation}->{"opt"} = $eqn2img_opt;
#            $history{$equation}->{"img"} = $pngfile;
#            $history{$equation}->{"dim"} = $dimstring;
#            $preexist = 1;
#          }
        } 
        if (! $preexist) {
          while(-e "$img_dir/$img_name$img_num.$format") { $img_num++ }; # never overwrite an image
          print "creating $img_dir/$img_name$img_num.$format: " if $verbose;
          #NOTE: windows doesn't like having commands spread out on more than one line!
          #      so don't supply any linebreaks in the options
          #      (perhaps remove linebreaks from options?)
#          # Following lines call eqn2img without using open2()... instead pass
#          # the equation on the command line with the -e option.
#           print "eqn2img $eqn2img_opt -o $img_dir/$img_name.$format " .
#                          "-e \"$equation\%$eqn2img_opt2\"\n";
#           open EQNTASK, ("eqn2img $eqn2img_opt -o $img_dir/$img_name.$format " .
#                          "-e \"$equation\%$eqn2img_opt2\"|");
#           $dimensions = <EQNTASK>;
#           close EQNTASK;
          $pid = open2(\*eqn2img_out, \*eqn2img_in, "eqn2img $eqn2img_opt -o $img_dir/$img_name$img_num.$format");
          eqn2img_in->autoflush();
          # Add the options on to equation as a TeX comment (% symbol) for purposes of matching
          # equation and comment (see earlier pre-existing check).
          # Note that we have stripped out the quotes from this version of the options.
          print eqn2img_in "$equation\%$eqn2img_opt2";
          print eqn2img_in "\cZ";  # send a control-Z to signal end of input (needed on windows)
          close eqn2img_in;
          $dimensions = <eqn2img_out>;
          waitpid $pid, 0; # close seems not to set $? when using open2, why is that?
          if($?) {
            print "Error processing equation starting at line $start_line:\n", $equation,"\n";
            exit;
          }
          close eqn2img_out;

          print " $dimensions, done.\n" if $verbose;
          # write the image attributes into the tex file for later reuse.
          open(TEXFILE, ">>$img_dir/$img_name$img_num.tex") 
            or die "can't open .tex file for writing image attributes!";
          print TEXFILE "\%img_attributes $dimensions";
          close TEXFILE;
          $history{$equation}->{"opt"} = $eqn2img_opt;
          $history{$equation}->{"img"} = "$img_name$img_num.$format";
          $history{$equation}->{"dim"} = $dimensions;
        }
      }
#      if (!$this_inline) {
#        print OUTPUT "<center>";
#      }
      print OUTPUT "<img src=\"".$img_src.$history{$equation}->{"img"}."\" "
             .$history{$equation}->{"dim"}." alt=\"$equation\">";
#      if (!$this_inline) {
#        print OUTPUT "</center>";
#      }
        
      $start_line = $end_line;
    }

    print OUTPUT "$line";
  }
  close(INPUT);
  close(OUTPUT);
  
  if ($extension eq "prep") {
    # delete the intermediate prep file that prep created earlier.
    unlink "$basename.$extension";
  }
}

