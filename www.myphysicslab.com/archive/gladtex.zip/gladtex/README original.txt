                  gladtex version 0.3
                  -------------------
(NOTE: see the file 'readme gladtex windows.txt' for information
about the windows version of gladtex)

Reads a 'htex' file (html with LaTeX maths embedded in <EQ></EQ>)
and produces html with equations substituted by images.

Project homepage at http://www.math.uio.no/~martingu/gladtex/
Copyright (C) 1999-2002 Martin G. Gulbrandsen <martingu@math.uio.no>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or (at
your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
USA


                    Installation
                    ------------

In a nutshell, just run
	make
and then (as root)
	make install
However, you may want to have a look at the Makefile first. BINPATH
specifies where to install gladtex, /usr/local/bin is default. To
compile without gif support, for instance in case of problems with gif
libraries, remove `-DGIF' and `-lungif' from the lines starting with
CC and LIB, respectively.

I haven't had the opportunity to test compilation on many systems
(development has taken place on a RedHat system), in particular there
may be library differences. For instance, you may have to change
'-lungif' to '-lgif' on some systems. Comments are welcome.


                    Quick start
                    -----------

Write HTML code as usual, but use LaTeX equations within the tags
<EQ>..</EQ>. Don't use .html extension, .htex is recommended. Now,
run:
      gladtex -v myfile.htex
The -v option is not mandatory, but gives you more feedback. If there
are no LaTeX errors, this will generate the file myfile.html (or
similar) and numerous eqn???.png files that contain images of your
equations. The HTML file generated is a copy of yours, but the
equations are substituted by links to the image files.

If you prefer gif files, add the option "-f gif". To see a quick list
of options, run gladtex with no arguments.


                       -----

Thanks to all users who have given feedback.

Detailed documentation is available online at
      http://www.math.uio.no/~martingu/gladtex/

Have fun.

                                           Martin G. Gulbrandsen
                                            martingu@math.uio.no
